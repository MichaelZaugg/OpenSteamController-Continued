Directory structure:
../
  | [some other files and directories]
  |
  | ValveFirmwareUpdateApp.exe --> Windows updater with nRF programming via SWD added
  | readme.txt               --> This file
  | ble.bat                  --> Batch file to flash BLE image
  | prod.bat                 --> Batch file to restore production FW image
  | updatescripts/
    | fw_images/
      | ble/                   --> Binaries from the latest state of the BLE controller firmware
      | production/            --> Binaries representing the initial state of the repository, with proprietary wireless.
				


==============================================
++++++++++++++++++++++++++++++++++++++++++++++
UPDATER
++++++++++++++++++++++++++++++++++++++++++++++
UPDATING TO BLE FIRMWARE
==============================================
!!! NOTE: the following presumes you are in the updatescripts/ directory described at the top of this file. !!!
Presuming that you are starting from a production controller, exit Steam and run the following to update the controller to the BLE firmware:
> ble.bat
Note: ble.bat runs two separate .bat files in sequence: blehost.bat and bleradio.bat


REVERTING TO PROPRIETARY WIRELESS FIRMWARE
==============================================
!!! NOTE: the following presumes you are in the updatescripts/ directory described at the top of this file. !!!
Presuming that you are starting from a BLE-enabled controller connected via USB, exit Steam and run the following to revert the controller to the proprietary wireless firmware:
> prod.bat
Note: prod.bat runs two separate .bat files in sequence: prodradio.bat and prodhost.bat